import BottomTabs from './BottomTabs';

export {
BottomTabs,
}