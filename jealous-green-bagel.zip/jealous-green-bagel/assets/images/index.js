import BackgroundS from './backgrounds.png'
import SplashS from './splashscreen.png'
import PhotoCoffe from './photocoffe.png'
import PhotoProfile from './photoprofile.png'

export {
    BackgroundS,
    SplashS,
    PhotoCoffe,
    PhotoProfile
}