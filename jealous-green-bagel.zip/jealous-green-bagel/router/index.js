import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { Home,Splashscreen,Favorite,Cart,Profile,Prodak } from '../pages';
import { BottomTabs } from '../components';

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

const MainApp = () => {
  return (
    <Tab.Navigator tabBar={(props) => <BottomTabs {...props} />}screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={Home} />
      <Tab.Screen name="Favorite" component={Favorite} />
      <Tab.Screen name="Cart" component={Cart} />
      <Tab.Screen name="Profile" component={Profile} />
    </Tab.Navigator>
  );
}

const Router = () => {
  return (
    <Stack.Navigator initialRouteName="MainApp" screenOptions={{headerShown: false}}>
      <Stack.Screen name="Splashscreen" component={Splashscreen}/>
      <Stack.Screen name="Prodak" component={Prodak}/>
      <Stack.Screen name="MainApp" component={MainApp}/>
    </Stack.Navigator>
  );
}

export default Router;