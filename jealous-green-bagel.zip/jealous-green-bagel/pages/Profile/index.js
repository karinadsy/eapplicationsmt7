import { Text, View } from 'react-native';

 const Profile = () => {
 return (
 <View>
 <Text>Profile</Text>
 </View>
 );
 };

 export default Profile;