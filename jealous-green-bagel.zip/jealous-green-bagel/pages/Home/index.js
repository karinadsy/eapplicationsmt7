import {
    StyleSheet, Text, View, Image, TouchableOpacity, TextInput, ScrollView
} from 'react-native';
import {
    PhotoProfile, Location, Notification, Filter, Search, Coffe, PhotoCoffe,
    FavoriteOFF, AddButton, FavoriteON
} from '../../assets';

const Home = ({navigation}) => {
    const categories = ['Cappucino', 'Espresso', 'Coffe', 'Latte'];

    return (
        <View style={styles.container}>
            <ScrollView>
                {/* Top Menu */}
                <View style={styles.topMenu}>
                    <TouchableOpacity activeOpacity={0.7}>
                        <Image style={styles.profileImage} source={PhotoProfile} />
                    </TouchableOpacity>
                    <TouchableOpacity activeOpacity={0.7} style={styles.locationWrapper}>
                        <Image source={Location} />
                        <Text style={styles.locationText}>Kedungwuni, Pekalongan</Text>
                    </TouchableOpacity>
                    <TouchableOpacity activeOpacity={0.7}>
                        <Image source={Notification} />
                    </TouchableOpacity>
                </View>

                {/* Greeting */}
                <View style={styles.greetingWrapper}>
                    <Text style={styles.greetingText}>Selamat Pagi, irl</Text>
                </View>

                {/* Search Bar */}
                <View style={styles.searchWrapper}>
                    <View style={styles.searchInputWrapper}>
                        <Image source={Search} />
                        <TextInput placeholder="Search Coffe ..." style={styles.searchInput} />
                    </View>
                    <TouchableOpacity activeOpacity={0.7}>
                        <Image source={Filter} />
                    </TouchableOpacity>
                </View>

                {/* Category Scroll */}
                <View style={styles.categoryWrapper}>
                    <Text style={styles.categoryTitle}>Kategori</Text>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        {categories.map((item, index) => (
                            <TouchableOpacity
                                key={index}
                                activeOpacity={0.7}
                                style={[
                                    styles.categoryButton,
                                    index > 0 && styles.categoryButtonSecondary,
                                ]}>
                                <Image source={Coffe} />
                                <Text
                                    style={[
                                        styles.categoryButtonText,
                                        index > 0 && { color: 'black' },
                                    ]}>
                                    {item}
                                </Text>
                            </TouchableOpacity>
                        ))}
                    </ScrollView>
                </View>

                {/* Product List */}
                <View style={styles.productWrapper}>
                    <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                        <TouchableOpacity activeOpacity={0.7} style={styles.productCard}
                            onPress={() => navigation.navigate('Prodak')}>
                            <Image source={PhotoCoffe} style={styles.productImage} />
                            <View style={styles.productHeader}>
                                <View style={styles.productInfo}>
                                    <Text style={styles.productName}>Cappuccino123</Text>
                                    <Text style={styles.productDesc}>With Sugar</Text>
                                </View>
                                <TouchableOpacity style={styles.favoriteWrapper}>
                                    <Image source={FavoriteOFF} />
                                </TouchableOpacity>
                            </View>
                            <View style={styles.productFooter}>
                                <Text>Rp 50.000</Text>
                                <Image source={AddButton} />
                            </View>
                        </TouchableOpacity>
                        {[0, 1, 2].map((i) => (
                            <TouchableOpacity key={i} activeOpacity={0.7}
                                style={styles.productCard}>
                                <Image source={PhotoCoffe} style={styles.productImage} />
                                <View style={styles.productHeader}>
                                    <View style={styles.productInfo}>
                                        <Text style={styles.productName}>Cappuccino</Text>
                                        <Text style={styles.productDesc}>With Sugar</Text>
                                    </View>
                                    <TouchableOpacity style={styles.favoriteWrapper}>
                                        <Image source={FavoriteOFF} />
                                    </TouchableOpacity>
                                </View>
                                <View style={styles.productFooter}>
                                    <Text>Rp 50.000</Text>
                                    <Image source={AddButton} />
                                </View>
                            </TouchableOpacity>
                        ))}
                    </ScrollView>
                </View>

                {/* Special Products */}
                <View style={styles.specialWrapper}>
                    <Text style={styles.categoryTitle}>Produk Spesial</Text>
                    {[0, 1].map((row) => (
                        <View key={row} style={styles.cardRow}>
                            {[false, true].map((fav, idx) => (
                                <TouchableOpacity
                                    key={idx}
                                    activeOpacity={0.7}
                                    style={[styles.productCard, idx === 1 && styles.productCardAlt]}>
                                    <Image source={PhotoCoffe} style={styles.productImage} />
                                    <View style={styles.productHeader}>
                                        <View style={styles.productInfo}>
                                            <Text style={styles.productName}>Cappuccino</Text>
                                            <Text style={styles.productDesc}>With Sugar</Text>
                                        </View>
                                    </View>
                                    <TouchableOpacity activeOpacity={0.7} style={styles.favoriteWrapper}>
                                        <Image source={fav ? FavoriteON : FavoriteOFF} />
                                    </TouchableOpacity>
                                    {/* --- PERBAIKAN DI SINI --- */}
                                    {/* Menghapus <View> yang tidak perlu dan tag penutup yang salah */}
                                    <View style={styles.productFooter}>
                                        <Text>Rp 50.000</Text>
                                        <Image source={AddButton} />
                                    </View>
                                    {/* Tag <TouchableOpacity> utama ditutup di sini */}
                                </TouchableOpacity>
                            ))}
                        </View>
                    ))}
                </View>
            </ScrollView>
        </View>
    );
};

export default Home;

// ... (styles tidak berubah)
const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    topMenu: {
        flexDirection: 'row',
        marginTop: 30,
        marginHorizontal: 30,
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    profileImage: {
        width: 32,
        height: 32,
    },
    locationWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    locationText: {
        fontWeight: '500',
        fontSize: 12,
        marginLeft: 5,
    },
    greetingWrapper: {
        marginHorizontal: 20,
        marginTop: 15,
    },
    greetingText: {
        fontWeight: '500',
        fontSize: 14,
    },
    searchWrapper: {
        flexDirection: 'row',
        backgroundColor: 'white',
        marginHorizontal: 20,
        paddingHorizontal: 20,
        paddingVertical: 5,
        borderRadius: 30,
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 20,
    },
    searchInputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        flex: 1,
    },
    searchInput: {
        marginLeft: 15,
        color: '#80A896',
    },
    categoryWrapper: {
        marginLeft: 20,
        marginTop: 30,
    },
    categoryTitle: {
        fontWeight: '500',
        marginBottom: 15,
        fontSize: 16,
    },
    categoryButton: {
        backgroundColor: '#00582F',
        paddingVertical: 8,
        paddingHorizontal: 15,
        flexDirection: 'row',
        alignItems: 'center',
        borderRadius: 30,
        marginRight: 10,
    },
    categoryButtonSecondary: {
        backgroundColor: 'white',
        borderColor: 'black',
    },
    categoryButtonText: {
        color: '#fff',
        marginLeft: 8,
    },
    productWrapper: {
        marginLeft: 20,
        marginTop: 20,
    },
    productCard: {
        backgroundColor: 'white',
        borderRadius: 20,
        padding: 10,
        marginRight: 15,
        elevation: 3,
        shadowColor: '#000',
    },
    productCardAlt: {
        marginLeft: 10,
    },
    productImage: {
        width: 141,
        height: 105,
        borderRadius: 20,
    },
    productHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 10,
    },
    productInfo: {
        flex: 1,
    },
    productName: {
        fontSize: 14,
        fontWeight: '500',
    },
    productDesc: {
        fontSize: 10,
        marginTop: 3,
    },
    favoriteWrapper: {
        marginLeft: 10,
    },
    productFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginTop: 8,
    },
    specialWrapper: {
        marginLeft: 20,
        marginTop: 30,
    },
    cardRow: {
        flexDirection: 'row',
        marginBottom: 15,
    },
});