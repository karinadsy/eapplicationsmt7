import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView, ImageBackground } from 'react-native';
import { PhotoCoffe, FavoriteOFF } from '../../assets';
import { FontAwesome, MaterialIcons } from '@expo/vector-icons';

const Prodak = ({navigation}) => {
    return (
        <View style={{flex: 1}}>
            <ScrollView showsVerticalScrollIndicator={true}>
                <ImageBackground source={PhotoCoffe}>
                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 30, marginHorizontal: 30}}>
                        <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: 'white', borderRadius: 30}} onPress={() => navigation.navigate('MainApp', {screen: 'Cart'})}>
                            <MaterialIcons name="keyboard-arrow-left" style={{fontSize: 24}} color="black" />
                        </TouchableOpacity>
                        <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: 'white', borderRadius: 30, paddingVertical: 5, paddingHorizontal: 5}} onPress={() => navigation.navigate('MainApp', {screen: 'Favorite'})}>
                            <Image source={FavoriteOFF} />
                        </TouchableOpacity>
                    </View>
                    <View style={{marginTop: 200, marginBottom: 40, flexDirection: 'row', justifyContent: 'space-between', marginHorizontal: 30, alignItems: 'center'}}>
                        <View>
                            <Text style={{fontSize: 32, color: 'white', fontWeight: '500'}}>Cappuccino</Text>
                            <Text style={{color: 'white'}}>With Sugar</Text>
                        </View>
                        <View style={{backgroundColor: '#C1925B', flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingVertical: 3, borderRadius: 30}}>
                            <FontAwesome name="star" size={18} color="white" />
                            <Text style={{marginLeft: 5, color: 'white'}}>4.8</Text>
                        </View>
                    </View>
                </ImageBackground>
                <View>
                    {/* detail ukuran */}
                    <View style={{backgroundColor: 'white', borderTopLeftRadius: 30, borderTopRightRadius: 30, marginTop: -30}}>
                        <View style={{marginHorizontal: 30, marginVertical: 15}}>
                            <Text style={{fontSize: 16, fontWeight: '500', marginBottom: 10}}>Cup Size</Text>
                            <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                                <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: '#00512C', paddingHorizontal: 20, paddingVertical: 5, borderRadius: 30, marginRight: 10}}>
                                    <Text style={{color: 'white', fontWeight: '500', fontSize: 16}}>Small</Text>
                                </TouchableOpacity>
                                <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: 'white', elevation: 5, shadowColor: 'black', paddingHorizontal: 20, paddingVertical: 5, borderRadius: 30, marginRight: 10}}>
                                    <Text style={{color: '#00512C', fontWeight: '500', fontSize: 16}}>Medium</Text>
                                </TouchableOpacity>
                                <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: 'white', elevation: 5, shadowColor: 'black', paddingHorizontal: 20, paddingVertical: 5, borderRadius: 30, marginRight: 10}}>
                                    <Text style={{color: '#00512C', fontWeight: '500', fontSize: 16}}>Large</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                        {/* level gula */}
                        <View style={{marginHorizontal: 30, marginVertical: 15}}>
                            <Text style={{fontSize: 16, fontWeight: '500', marginBottom: 10}}>Level Sugar:</Text>
                            <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                                <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: '#00512C', paddingHorizontal: 20, paddingVertical: 5, borderRadius: 30, marginRight: 10}}>
                                    <Text style={{color: 'white', fontWeight: '500', fontSize: 16}}>No Sugar</Text>
                                </TouchableOpacity>
                                <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: 'white', elevation: 5, shadowColor: 'black', paddingHorizontal: 20, paddingVertical: 5, borderRadius: 30, marginRight: 10}}>
                                    <Text style={{color: '#00512C', fontWeight: '500', fontSize: 16}}>Low</Text>
                                </TouchableOpacity>
                                <TouchableOpacity activeOpacity={0.7} style={{backgroundColor: 'white', elevation: 5, shadowColor: 'black', paddingHorizontal: 20, paddingVertical: 5, borderRadius: 30, marginRight: 10}}>
                                    <Text style={{color: '#00512C', fontWeight: '500', fontSize: 16}}>Medium</Text>
                                </TouchableOpacity>
                            </View>
                        </View>
                        {/* about */}
                        <View style={{marginHorizontal: 30}}>
                            <Text style={{fontSize: 16, fontWeight: '500', marginBottom: 10}}>About</Text>
                            <Text>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse imperdiet velit et dolor lobortis, vitae aliquam dolor porta. Duis ac ligula ac metus suscipit lobortis in at neque. Sed eu nunc rutrum, porttitor nibh a, finibus dolor. Morbi malesuada, nibh sed pulvinar sagittis, ex est posuere diam ...
                                <TouchableOpacity activeOpacity={0.7}>
                                    <Text style={{fontWeight: '500'}}>Read More</Text>
                                </TouchableOpacity>
                            </Text>
                        </View>
                        {/* add to cart */}
                        <View style={{marginHorizontal: 30, marginTop: 30}}>
                            <TouchableOpacity activeOpacity={0.7}
                                style={{backgroundColor: '#00512C', alignItems: 'center', borderRadius: 30, paddingVertical: 20}} onPress={() => navigation.navigate('MainApp', {screen: 'Cart'})}>
                                <Text style={{fontSize: 20, color: 'white', fontWeight: '500'}}>Rp 50.000 | Add to Card</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </ScrollView>
        </View>
    );
};

export default Prodak;