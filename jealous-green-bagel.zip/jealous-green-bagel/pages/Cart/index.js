import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView } from 'react-native';
import React, { useState } from 'react';
import { PhotoCoffe, FavoriteOFF, AddButton } from '../../assets';
import { FontAwesome5, AntDesign } from '@expo/vector-icons';

const Cart = ({navigation}) => {
    const [counts, setCounts] = useState({});

    const plus = (id) => {
        setCounts(prev => ({
            ...prev,
            [id]: (prev[id] || 0) + 1
        }));
    };

    const minus = (id) => {
        setCounts(prev => {
            const current = prev[id] || 0;
            if (current <= 0) return prev;
            return {
                ...prev,
                [id]: current - 1
            };
        });
    };

    const data = [
        { id: 'cappuccino01', name: 'Cappuccino', sugar: 'With Sugar', price: 'Rp 50.000' },
        { id: 'latte01', name: 'Latte', sugar: 'Less Sugar', price: 'Rp 60.000' },
        { id: 'americano01', name: 'Americano', sugar: 'No Sugar', price: 'Rp 45.000' }
    ];

    return (
        <View style={{flex: 1, marginTop: 20}}>
            <ScrollView>
                <View style={{marginLeft: 30, marginTop: 30}}>
                    <Text style={{fontWeight: '500'}}>Cart</Text>
                    {/* Favorite */}
                    <View>
                        {data.map(item => (
                            <TouchableOpacity
                                key={item.id}
                                activeOpacity={0.7}
                                style={{
                                    backgroundColor: 'white',
                                    borderRadius: 20,
                                    padding: 10,
                                    marginBottom: 15,
                                    elevation: 5,
                                    shadowColor: 'black',
                                }}
                                onPress={() => navigation.navigate('Prodak')}>
                                <View style={{flexDirection: 'row', justifyContent: 'space-between'}}>
                                    <View style={{flexDirection: 'row'}}>
                                        <Image source={PhotoCoffe} style={{width: 100, height: 100, borderRadius: 20}} />
                                        <View style={{marginLeft: 10, justifyContent: 'center'}}>
                                            <Text style={{fontSize: 14, fontWeight: '500'}}>{item.name}</Text>
                                            <Text style={{fontSize: 10, marginTop: 5}}>{item.sugar}</Text>
                                            <Text style={{fontSize: 18, fontWeight: '500'}}>{item.price}</Text>
                                        </View>
                                    </View>
                                    <TouchableOpacity activeOpacity={0.7} style={{marginTop: 10}}>
                                        <Image source={FavoriteOFF} />
                                    </TouchableOpacity>
                                </View>
                                <View
                                    style={{
                                        flexDirection: 'row',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        marginTop: 10
                                    }}>
                                    <View>
                                        <Text style={{color: '#686868', fontSize: 12}}>
                                            Cup Size: <Text style={{fontWeight: '500', color: 'black'}}>Small</Text>
                                        </Text>
                                        <Text style={{color: '#686868', fontSize: 12}}>
                                            Level Sugar: <Text style={{fontWeight: '500', color: 'black'}}>No Sugar</Text>
                                        </Text>
                                    </View>
                                    <View style={{flexDirection: 'row', alignItems: 'center'}}>
                                        <TouchableOpacity activeOpacity={0.7} onPress={() => minus(item.id)}>
                                            <AntDesign name="minuscircle" size={22} color="#00512C" />
                                        </TouchableOpacity>
                                        <Text style={{fontSize: 32, fontWeight: '500', marginHorizontal: 10}}>{counts[item.id] || 0}</Text>
                                        <TouchableOpacity activeOpacity={0.7} onPress={() => plus(item.id)}>
                                            <Image source={AddButton} />
                                        </TouchableOpacity>
                                    </View>
                                </View>
                            </TouchableOpacity>
                        ))}
                    </View>
                </View>
                <View>
                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 15}}>
                        <Text>Subtotal</Text>
                        <Text>Rp 100.000</Text>
                    </View>
                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 5}}>
                        <Text>Discount</Text>
                        <Text>Rp 25.000</Text>
                    </View>
                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 30}}>
                        <Text>Total</Text>
                        <Text>Rp 75.000</Text>
                    </View>
                </View>
                <View style={{marginTop: 25}}>
                    <Text>Payment</Text>
                    <View style={{flexDirection: 'row', marginTop: 10}}>
                        <TouchableOpacity>
                            <FontAwesome5 name="cc-visa" size={40} color="black" />
                        </TouchableOpacity>
                        <TouchableOpacity style={{marginHorizontal: 10}}>
                            <FontAwesome5 name="cc-mastercard" size={40} color="black" />
                        </TouchableOpacity>
                        <TouchableOpacity>
                            <FontAwesome5 name="cc-paypal" size={40} color="black" />
                        </TouchableOpacity>
                    </View>
                </View>
                <TouchableOpacity activeOpacity={0.7}
                    style={{backgroundColor: '#00512C', paddingVertical: 10, alignItems: 'center', borderRadius: 30, margin: 10}} onPress={() => navigation.navigate('Home')}>
                    <Text style={{fontSize: 20, color: 'white', fontWeight: '500'}}>Beli</Text>
                </TouchableOpacity>
            </ScrollView>
        </View>
    );
};

export default Cart;

const styles = StyleSheet.create({});