import Splashscreen from './Splashscreen';
import Home from './Home';
import Favorite from './Favorite';
import Cart from './Cart';
import Profile from './Profile';
import Prodak from './Prodak';

export {
    Splashscreen,
    Home,
    Favorite,
    Cart,
    Profile,
    Prodak,
}