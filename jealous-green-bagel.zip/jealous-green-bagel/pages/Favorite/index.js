import { StyleSheet, Text, View, Image, TouchableOpacity, ScrollView } from 'react-native';
import { PhotoCoffe, FavoriteOFF, FavoriteON, AddButton } from '../../assets';

const Favorite = () => {
    return (
        <View style={styles.container}>
            <ScrollView>
                <View style={styles.scrollWrapper}>
                    <View>
                        <Text style={styles.sectionTitle}>Favorite</Text>
                        {/* Favorite Cards */}
                        {[0, 1, 2, 3].map((row, rowIndex) => (
                            <View style={styles.cardRow} key={rowIndex}>
                                {[0, 1].map((col, colIndex) => {
                                    const isAlt = colIndex % 2 === 1;
                                    const isOn = (rowIndex + colIndex) % 2 === 1;

                                    return (
                                        <TouchableOpacity
                                            key={colIndex}
                                            activeOpacity={0.7}
                                            style={[styles.card, isAlt && styles.cardAlt]}>
                                            <Image source={PhotoCoffe} style={styles.coffeeImage} />
                                            <View style={styles.cardHeader}>
                                                <View style={styles.cardHeaderLeft}>
                                                    <Text style={styles.coffeeName}>Cappuccino</Text>
                                                    <Text style={styles.coffeeDesc}>With Sugar</Text>
                                                </View>
                                                <TouchableOpacity activeOpacity={0.7}
                                                    style={styles.favoriteIconWrapper}>
                                                    <Image source={isOn ? FavoriteON : FavoriteOFF} />
                                                </TouchableOpacity>
                                            </View>
                                            <View style={styles.cardFooter}>
                                                <Text>Rp 50.000</Text>
                                                <Image source={AddButton} />
                                            </View>
                                        </TouchableOpacity>
                                    );
                                })}
                            </View>
                        ))}
                    </View>
                </View>
            </ScrollView>
        </View>
    );
};

export default Favorite;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop: 20,
    },
    scrollWrapper: {
        marginLeft: 30,
        marginRight: 30,
    },
    sectionTitle: {
        fontWeight: '500',
        marginBottom: 15,
    },
    cardRow: {
        flexDirection: 'row',
    },
    card: {
        backgroundColor: 'white',
        borderRadius: 20,
        paddingHorizontal: 5,
        paddingVertical: 5,
        elevation: 5,
        shadowColor: 'black',
        marginHorizontal: 5,
        marginVertical: 10,
    },
    cardAlt: {
        marginHorizontal: 20,
    },
    coffeeImage: {
        width: 144,
        height: 105,
        borderRadius: 20,
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
    },
    cardHeaderLeft: {
        marginTop: 10,
    },
    coffeeName: {
        fontSize: 14,
        fontWeight: '500',
    },
    coffeeDesc: {
        fontSize: 10,
        marginTop: 5,
    },
    favoriteIconWrapper: {
        marginTop: 10,
    },
    cardFooter: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
});