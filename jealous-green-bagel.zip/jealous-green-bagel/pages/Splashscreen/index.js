import { StyleSheet, Text, View, Image, ImageBackground, TouchableOpacity } from 'react-native';
import { BackgroundS, SplashS } from '../../assets/images';

const Splashscreen = ({ navigation }) => {
    return (
        <View style={styles.container}>
            <ImageBackground source={BackgroundS} style={styles.background}>
                <View style={styles.imageWrapper}>
                    <Image source={SplashS} />
                </View>
                <View style={styles.titleWrapper}>
                    <Text style={styles.title}>Coffe so good, your taste buds will love it</Text>
                </View>
                <View style={styles.subtitleWrapper}>
                    <Text style={styles.subtitle}>The best grain, the finest roas, the most powerful flavor</Text>
                </View>
                <TouchableOpacity
                    activeOpacity={0.7}
                    style={styles.button}
                    onPress={() => navigation.navigate('MainApp')}
                >
                    <Text style={styles.buttonText}>Get Started</Text>
                </TouchableOpacity>
            </ImageBackground>
        </View>
    );
};

export default Splashscreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
    },
    background: {
        flex: 1,
        width: '100%',
        height: '100%',
    },
    imageWrapper: {
        marginTop: 120,
        alignItems: 'center',
    },
    titleWrapper: {
        marginTop: 30,
        paddingHorizontal: 100,
    },
    title: {
        fontSize: 24,
        fontWeight: '500',
        color: 'white',
        textAlign: 'center',
    },
    subtitleWrapper: {
        marginTop: 30,
        paddingHorizontal: 90,
    },
    subtitle: {
        fontSize: 14,
        color: 'white',
        textAlign: 'center',
    },
    button: {
        backgroundColor: '#00512C',
        alignItems: 'center',
        paddingHorizontal: 30,
        paddingVertical: 15,
        borderRadius: 30,
        marginHorizontal: 60,
        marginTop: 30,
    },
    buttonText: {
        fontSize: 16,
        fontWeight: '600',
        color: 'white',
    },
});